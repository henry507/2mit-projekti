# Integraatioprojekti

Management portaalissa, Web Application luotu seuraavasti:
- General välilehti
    - Nimi: /REST
    - Namespace: AMK (ei väliä mikä kullakin kehittäjällä)
    - Enable Application: Check
    - REST, Dispatch class: User.RESTService
    - Security Settings: Unauthenticated
    
- Application Roles
    - %All
